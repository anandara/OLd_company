#declare a vector
loopcounter<-c(1,2,3,4,5)
##For loop { position matters}
for(l in loopcounter){
  print(paste("Line",as.character(l)))
}

## For loop is for operating on all elements of collection

WhileLoopCounter<-1
while(WhileLoopCounter < length(loopcounter)){

  print(paste("Line",as.character(WhileLoopCounter)))
  WhileLoopCounter <-WhileLoopCounter+1
  
}
#while till a condition is satisfied