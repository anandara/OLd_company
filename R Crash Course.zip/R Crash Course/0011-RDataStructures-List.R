### The various data structures avaiable in R
#Depending on number of dimensions and if you are going to use the same or different 
#type of data , you can pick suitable one!!!
----------------------------------------------------------------------------------------
  #    Homogeneous	     Heterogeneous
  #1d	 Atomic 
  #    vector	           List
  #2d	 Matrix	           Data frame
  #nd	 Array	
  #######################################################################################
#Refer the Data Structures.Png for how data structure would look like!!! Very
#important for quicker understanding


###Lists are similar to Vectors but they can contain all data types
cat("\0014")
varList=list("AssociateId"=234768,"FirstName"="Balachandar","LastName"="Ganesan","Offshore"=TRUE)

##You can see contents of list via str function
str(varList)
varList

## Various ways to get contents of list
print("Get value from list via index")
varList[[1]]
print("Get value from list via Column Name")
varList$FirstName

### Add Elements to List
varList[["Location"]]="Chennai"
print("Added Location")
str(varList)

###Modify Elements of a list

varList[["LastName"]]="Ganesan N"
print("Modified Last Name")
str(varList)
###Delete Elements of a list
### Assign value NA to specific element
varList[["Location"]]=NULL
print("Deleting Location")
str(varList)