var1-> "balachandar"
print(var1)
print(Var1)