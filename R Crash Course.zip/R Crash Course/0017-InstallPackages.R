### download TidyVerse packages
install.packages("XLConnect")
##install locally
library(XLConnect)
## remove it
### this package can be used for reading excel file..
###please save an excel into local working directory and read from it
cat("\014")
setwd("D:\\Delivery Management\\Technology Management\\R\\Exercises\\R Absolute Beginners\\")
df = readWorksheetFromFile("myfile.xlsx", sheet="Sheet1" ,
                             startRow = 0, endRow = 10, startCol = 0, endCol = 0)
print(df)
###Unload the package via detach command
detach("package:XLConnect",TRUE)
###

