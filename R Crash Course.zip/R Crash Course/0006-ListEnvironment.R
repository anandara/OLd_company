##List all variables
ls()
## remove the variable listed var1 in this case
rm(var1)
ls()

