str<-"This is Balachandar Ganesan here"
substring<-substr(str,9,20)
#get the substring
print(substring)

#replace function
print(sub("is","was",str))
print(str)

#Split the string
print(strsplit(str,"Bala"))

#merge strings
print(paste("bala","chandar"))


## have the value balachandar ganesan and 
## want to print Balachandar Ganesan ... The first letter being capital

Name<-"balachandar ganesan"

##Split Name into two parts using strsplit function
### Getting them into a data structure called list in R...
### Search for more on list in R

tmpNameSplit=strsplit(Name," ",TRUE)

##Printing the output
print(tmpNameSplit)

###Now Splitting them into first name and last name
print(tmpNameSplit[[1]][1])
print(tmpNameSplit[[1]][2])


### Assigning them into two variables
FirstName=tmpNameSplit[[1]][1]
LastName=tmpNameSplit[[1]][2]


### toUpper function to convert case
FirstNameFirstLetter =toupper(substr(FirstName,1,1))
print(FirstName)
print(nchar(FirstName))
FirstNameOtherLetters=substr(FirstName,2,nchar(FirstName))
print(FirstNameOtherLetters)
###using paste function for merging...
paste(FirstNameFirstLetter,FirstNameOtherLetters)

###Moify further ... Need to remove unwanted space..
paste(FirstNameFirstLetter,FirstNameOtherLetters,sep="")


### Else you can use paste0 function as well
paste0(FirstNameFirstLetter,FirstNameOtherLetters)


#### Play around with paste!!!!
CenterLeads <- c("Amol","Vijay", "Bidesh","Anirban","Balasundaram","Johnson","Arun")
paste("Hello Center Lead",CenterLeads)
#### Try converting BALACHANDAR GANESAN into Balachandar Ganesan

###  Exercises!!!!

print(tolower(FirstNameFirstLetter))

