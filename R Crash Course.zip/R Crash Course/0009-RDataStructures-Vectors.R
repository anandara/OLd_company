### The various data structures avaiable in R
#Depending on number of dimensions and if you are going to use the same or different 
#type of data , you can pick suitable one!!!
----------------------------------------------------------------------------------------
#    Homogeneous	     Heterogeneous
#1d	 Atomic 
#    vector	           List
  
#2d	 Matrix	           Data frame
  
#nd	 Array	
#######################################################################################
#Refer the Data Structures.Png for how data structure would look like!!! Very
#important for quicker understanding

### Vector
### Single Dimension Structure
### Any Data Type
### But all elements should be of same data type
### created with c function!!!
cat("\0014")
### Vector of integers
vectIntegers =c(1,2,3,4)
### Vector of Large Integers
vectLargeIntegers=c(1L,2L,3L,4L)
print(vectLargeIntegers)

###Vector of strings
vectStrings =c("Balachandar","Ganesan")

### You can assign function to assign values as well

assign("VectNew",c(2,3,4,7,6,8))
print(VectNew)

--## Vectors are flat even if they are nested...
cat("\0014")
varArun=c("Arun",c("Rajendran"))
print(varArun)


##You can access by indexing
print(varArun[1])
print(paste(varArun[1],varArun[2]))

###Other Functions in Vectors

varNumbers =c(1,2,3,4,5)
print("Minimum is")
print(min(VarNumbers))
print("Maximum is")
print(max(varNumbers))
print("Range is")
print(range(varNumbers))
print("sum is")
print(sum(varNumbers))
print("Product is")
print(prod(varNumbers))
print("Average is")
print(mean(varNumbers))

## Vectors can be created by sequence and rep function as well

varNumbers =seq(8,24,2)
print("Vector using Sequence Function")
print(varNumbers)

varNumbers =rep(8,3)
print("Vector using rep Function")
print(varNumbers)
