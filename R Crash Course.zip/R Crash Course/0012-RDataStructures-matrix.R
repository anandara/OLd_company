### The various data structures avaiable in R
#Depending on number of dimensions and if you are going to use the same or different 
#type of data , you can pick suitable one!!!
----------------------------------------------------------------------------------------
  #    Homogeneous	     Heterogeneous
  #1d	 Atomic 
  #    vector	           List
  #2d	 Matrix	           Data frame
  #nd	 Array	
  #######################################################################################
#Refer the Data Structures.Png for how data structure would look like!!! Very
#important for quicker understanding


###Matrix is for 2d and same type of data


print ("How to create a matrix")
varMatrixSample <- matrix(nrow=2,ncol=2)
print(" Empty Matrix. as Now values are assigned")
print(varMatrixSample)

print("Let us assign Values")
varMatrixSample[1,1]<-1
varMatrixSample[1,2]<-2
varMatrixSample[2,1]<-3
varMatrixSample[2,2]<-4

print("  Matrix. as Now values are assigned")
print(varMatrixSample)

## How to retrieve Value
print(varMatrixSample[2,2])

## How to retrieve Column---First Column

print(varMatrixSample[,1])
## How to retrieve Row---Second Row
print(varMatrixSample[2,])

### Assigning Row Headers and Column headers
colnames(varMatrixSample)<-c("Col1","Col2")
rownames(varMatrixSample)<-c("row1","row2")
print(varMatrixSample)

  ### Other Ways Creating Matrix-- Using Cbind,use column based merging of vectors
  varMatrixSample<- cbind(c(11,17),c(23,41))
  print(varMatrixSample)

  ### Other Ways Creating Matrix-- Using rbind,use row based merging of vectors
  varMatrixSample<- rbind(c(11,17),c(23,41))
  print(varMatrixSample)
  
  ### Convert a vector into matrix via dim function
  x<- c(1,2,3,4,5,6)
  print(x)
  dim(x)<-c(3,2)
  print(x)
  dim(x)<-c(2,3)
  print(x)
  