### Vector values can be named

cat("\0014")
varVectorName =c(FirstName="Balachandar",LastName="Ganesan")
print("Accessing Via Column Name")
print(varVectorName["LastName"])
print("Accessing via Index")
print(varVectorName[2])
print(names(varVectorName))

### "Categorical data using Factors

varDesignation=c("PAT","PAT","A","SA","A","SA","M","SM","M")
levels(varDesignation)
fctDesignation=factor(varDesignation)
print(varDesignation)
print(fctDesignation)
levels(fctDesignation)
print("Get Count using Table Function ")
table(fctDesignation)