### The various data structures avaiable in R
#Depending on number of dimensions and if you are going to use the same or different 
#type of data , you can pick suitable one!!!
----------------------------------------------------------------------------------------
  #    Homogeneous	     Heterogeneous
  #1d	 Atomic 
  #    vector	           List
  #2d	 Matrix	           Data frame
  #nd	 Array	
  #######################################################################################
#Refer the Data Structures.Png for how data structure would look like!!! Very
#important for quicker understanding


###DataFrame is for 2d and covers different type of data

cat("\0014")
##Create a data frame
subjects<- c("Tamil","English","Maths")
NoOfStudents<- c(33,31,34)
dfExample<-data.frame(subjects,NoOfStudents)
names(dfExample)<-c("Subjects","No.Of.Students")
print(dfExample)

##Get Data Frame Properties
nrow(dfExample)
ncol(dfExample)

##Access the elements of DataFrame
dfExample[1,2]
dfExample[2,1]


##See all properties of Data Frame
str(dfExample)

##Other functions
summary(dfExample)

##Access the elements by name
dfExample$Subjects
dfExample$No.Of.Students

##Add a department to Data Frame
dfExample$TeacherName<-c("Arun","Amol","Pankaj")
str(dfExample)


##Extract Few Rows with subset
subset(dfExample,dfExample$No.Of.Students==31)
subset(dfExample,dfExample$TeacherName=="Arun")