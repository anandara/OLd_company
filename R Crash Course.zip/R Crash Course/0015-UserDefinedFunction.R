##Write a function
##Finds the number of 2s in a list
###define the function here
### Use the function in next example
ValueCount<-function(x,v){
  c<-0
  for(l in x){
      if(l==v){c<-c+1}
    
    
  }
  return(c)
}