#Sample program for print statement
n<-"Hello Aaradhana"
print(n)
"Hello Balachandar"->n
print(n)

