##Get the working directory
getwd()
##Set it to where you want it
## \\ might be needed
setwd("D:\\Delivery Management\\Technology Management\\R\\Exercises\\R Absolute Beginners")
getwd()

### read from the file using read method
mydata<-read.csv("myfile.csv")

###Add another column % for Col4 to view as the % of total
##prop.table function can take a column of frame and return another vector
##prop stands for propertions
mydata$col4percentage<-prop.table(mydata$col4)
print(mydata)


##Let us do some charting using plot function
plot(mydata$col1,mydata$col2)
lines(mydata$col2)

##include header , x labels, y labels
plot(mydata$col1,mydata$col2,main="Demo Chart",xlab="abcde",ylab="values")
lines(mydata$col2)

### Save this as PDF
pdf("PDF Example.pdf",height = 7,width = 5)
plot(mydata$col1,mydata$col2,main="Demo Chart",xlab="abcde",ylab="values")
lines(mydata$col2)
dev.off()

##write into file pick only two columns
outputdata<-data.frame(mydata$col1,mydata$col4)
write.table(outputdata,"Output.csv")