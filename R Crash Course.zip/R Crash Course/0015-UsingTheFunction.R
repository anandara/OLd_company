###Use the user defined function
source("0015-UserDefinedFunction.r")
ValueCount(c(1,2,3,4,5,2,2,2),2)
## you get 4!!!