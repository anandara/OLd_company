require(ggplot2)
SachinData<-read.csv("SachinODIs.csv",header=TRUE,sep=",")
ggplot(SachinData, aes(BallsFaced, Runs)) + geom_point(aes(color = Opposition)) + 
  scale_x_continuous("Balls Faced", breaks = seq(0,160,20))+
  scale_y_continuous("Runs Scored", breaks = seq(0,200,by = 20))+ 
  theme_bw() + labs(title="Sachin One Day Statistics") + facet_wrap( ~ Opposition)



