#Sample program for print statement
n<-"Hello Aaradhana"
print(n)
"Hello Balachandar"->n
print(n)

r<-(10+2-3*1/4)^2 %%5
print(r)
r<-10+2
print(r)
r<-10+2-3
print(r)
r<-10+2-3*1
print(r)
r<-10+2-3*1/4
print(r)
r<-(10+2-3*1/4)^2
print(r)
r<-(10+2-3*1/4)^2 %%5
print(r)

cat("\014")

