SachinData<-read.csv("SachinODIs.csv")
### Simple Linear Regression for Runs and Balls Faced
lm(formula = Runs ~ BallsFaced,data=SachinData)

### Please see the result
###Coefficients:
###  (Intercept)   BallsFaced  
###-3.9152       0.9467  

### The Equation from above is

###
###Runs= 0.9467 * BallsFaced -3.91

### Suppose if he faces 40 balls
print( 0.9467*40-3.91)
### He will score 33 runs
