### The various data structures avaiable in R
#Depending on number of dimensions and if you are going to use the same or different 
#type of data , you can pick suitable one!!!
----------------------------------------------------------------------------------------
#    Homogeneous	     Heterogeneous
#1d	 Atomic 
#    vector	           List
#2d	 Matrix	           Data frame
#nd	 Array	
#######################################################################################
#Refer the Data Structures.Png for how data structure would look like!!! Very
#important for quicker understanding

### Atomic
### R is not strictly typed. It can change the data type based on value assigned.
cat("\014")

var1=1
typeof(var1)
length(Var1)

var2=2.5
typeof(var2)
length(var2)

var3="I am in MSFT"
typeof(var3)
length(var3)

var4=TRUE
typeof(var4)
length(var4)


