## Beware implcit Data Type conversion occurs

print(1==1)
print(1=="1")
print(1<1)
print(1>=1)
print(1!=1)
print(1!="1")
