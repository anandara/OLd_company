cat("\004")
var1<-4
print(var1%%2)
if(var1%%2==0)
{
  print("Even Number") 
  print(var1)
}else
{
  print("Odd Number")
}

# if else is not close to } .. it would give error
#please correct else as above and run
var1<-5
print(var1%%2)
if(var1%%2==0)
{
  print("Even Number")
}#else
else
{
  print("Odd Number")
  print(var1)
}

##Another version for ifElse

var1<-6
ifelse((var1==6),print("if"),print("else"))


